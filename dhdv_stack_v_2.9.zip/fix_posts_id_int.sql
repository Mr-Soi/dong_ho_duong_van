﻿IF EXISTS (
  SELECT 1 FROM sys.columns 
  WHERE object_id=OBJECT_ID('dbo.Posts')
    AND name='Id' AND system_type_id=TYPE_ID('bigint')
)
BEGIN
  PRINT 'Rebuild Posts with INT keys';
  CREATE TABLE dbo.Posts_fix(
    Id         INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
    Title      NVARCHAR(300) NOT NULL,
    Slug       NVARCHAR(160) NOT NULL,
    Summary    NVARCHAR(MAX) NULL,
    Content    NVARCHAR(MAX) NOT NULL,
    PublishedAt DATETIME NULL,
    UpdatedAt   DATETIME NULL,
    IsPublished BIT NOT NULL,
    CategoryId  INT NULL,
    CoverImage  NVARCHAR(500) NULL,
    CreatedAt   DATETIME2 NOT NULL
  );

  SET IDENTITY_INSERT dbo.Posts_fix ON;
  INSERT dbo.Posts_fix (Id,Title,Slug,Summary,Content,PublishedAt,UpdatedAt,IsPublished,CategoryId,CoverImage,CreatedAt)
  SELECT CAST(Id AS INT),Title,Slug,Summary,Content,PublishedAt,UpdatedAt,IsPublished,CAST(CategoryId AS INT),CoverImage,CreatedAt
  FROM dbo.Posts;
  SET IDENTITY_INSERT dbo.Posts_fix OFF;

  DROP TABLE dbo.Posts;
  EXEC sp_rename 'dbo.Posts_fix','Posts';
END
