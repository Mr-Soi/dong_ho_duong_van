﻿IF OBJECT_ID('dbo.vw_PostsForImport','V') IS NOT NULL DROP VIEW dbo.vw_PostsForImport;
GO
CREATE VIEW dbo.vw_PostsForImport AS
SELECT TOP 0

FROM (VALUES(1)) v(x);
GO
