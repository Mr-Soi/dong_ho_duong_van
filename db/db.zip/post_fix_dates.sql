﻿IF NOT EXISTS (SELECT 1 FROM dbo.Categories WHERE Slug=N'tin-tuc')
  INSERT INTO dbo.Categories(Name,Slug,CreatedAt) VALUES (N'Tin tức',N'tin-tuc',SYSUTCDATETIME());
DECLARE @CatDefault int=(SELECT TOP 1 Id FROM dbo.Categories WHERE Slug=N'tin-tuc');

UPDATE p
SET  p.PublishedAt = COALESCE(NULLIF(p.PublishedAt,'1900-01-01'), p.CreatedAt, SYSUTCDATETIME()),
     p.CategoryId  = COALESCE(p.CategoryId, @CatDefault),
     p.Summary     = COALESCE(p.Summary, N''),
     p.CoverImage  = COALESCE(NULLIF(p.CoverImage,N''), N'/img/uploads/logo_www.png');
